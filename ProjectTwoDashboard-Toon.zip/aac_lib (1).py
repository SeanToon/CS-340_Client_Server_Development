from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = '1234MandS'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30197
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be a dictionary
            return True
        else:
            return False

    def read(self, query):
        if query:
            result = self.database.animals.find(query)
            return list(result)
        else:
            return False
        
    def update(self, query, data):
        if query:
            result = self.database.animals.update_many(query, {'$set': data})
            return result.modified_count
        else: 
            return False
        
    def delete(self, query):
        if query:
            result = self.database.animals.delete_many(query)
            return result.deleted_count
        else:
            return False

        